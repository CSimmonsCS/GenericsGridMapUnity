------------------- Code Monkey -------------------

Thank you for downloading the Code Monkey Utilities
I hope you find them useful in your projects
If you have any questions use the contact form
Cheers!

           unitycodemonkey.com
--------------------------------------------------

Version: 1.00
Date: 14-05-2018